const express = require('express');
const router = express.Router();
const Furniture = require('../models/Furniture');

// Get all furniture items
router.get('/', async (req, res) => {
  try {
    const items = await Furniture.find();
    res.json(items);
  } catch (error) {
    res.status(500).json({ msg: 'Server error' });
  }
});
router.get('/:id', async (req, res) => {
  try {
    const furniture = await Furniture.findById(req.params.id);
    if (!furniture) return res.status(404).json({ message: 'Product not found' });
    res.json(furniture);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;


