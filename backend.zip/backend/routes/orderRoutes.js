


const express = require('express');
const router = express.Router();
const mongoose = require('mongoose'); // Add this line
const Order = require('../models/order'); // Update this path as needed
const nodemailer = require('nodemailer');

// Configure the SMTP transport with direct credentials
const transporter = nodemailer.createTransport({
    service: 'gmail',
    secure: true, // Set to true for port 465
    auth: {
        user: 'subharanjanapalanisamy@gmail.com', // Your email address
        pass: 'judw lvwq thaa nytg', // Your email password or app password
    },
});

// Function to send confirmation email to the user
const sendOrderConfirmation = async (email, orderId, username) => {
    const mailOptions = {
        from: 'subharanjanapalanisamy@gmail.com',
        to: email,
        subject: 'Order Placed Successfully',
        text: `Dear ${username},\n\nYour order has been placed successfully! Your order ID is: ${orderId}.\n\nThank you for shopping with us!\n\nBest regards,\nThe Team`,
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log(`Confirmation email sent to ${email} for order ID: ${orderId}`);
    } catch (err) {
        console.error(`Error sending confirmation email to ${email}:`, err);
        throw err; // Re-throw the error to be handled in the calling function
    }
};

// Function to notify admin about the new order
const notifyAdmin = async (orderId, username) => {
    const mailOptions = {
        from: 'subharanjanapalanisamy@gmail.com',
        to: 'lakshitha4224@gmail.com', // Replace with admin's email address
        subject: 'New Order Received',
        text: `A new order has been placed.\n\nUsername: ${username}\nOrder ID: ${orderId}\n\nPlease check the admin panel for more details.`,
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log(`Admin notified about order ID: ${orderId}`);
    } catch (err) {
        console.error(`Error notifying admin for order ID: ${orderId}:`, err);
        throw err;
    }
};

// POST route to create a new order
router.post('/orders', async (req, res) => {
    const { username, products, shippingInfo, paymentMethod, totalAmount, flexibleDeliveryDay } = req.body;

    // Convert productId to ObjectId
    const formattedProducts = products.map(item => ({
        productId: new mongoose.Types.ObjectId(item.productId), // Convert to ObjectId
        name: item.name,
        price: item.price,
        quantity: item.quantity,
    }));

    // Calculate delivery date (7 days from now)
    const deliveryDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    // Determine payment status
    const paymentStatus = paymentMethod === 'Cash on Delivery' ? 'Pending' : 'Completed';

    try {
        console.log('Starting order creation process...');
        
        // Find the order for the user
        let order = await Order.findOne({ username });
        console.log('Order for user found:', !!order);

        if (order) {
            console.log('Updating existing order...');
            // If order exists, push the new order into the orders array
            order.orders.push({
                products: formattedProducts, // Use formatted products
                shippingInfo: {
                    ...shippingInfo,
                    deliveryDate, // Set calculated delivery date
                    flexibleDeliveryDay, // Include flexible delivery day
                },
                paymentMethod,
                paymentStatus,
                totalAmount,
                createdAt: Date.now(),
            });
            await order.save();
        } else {
            console.log('Creating new order...');
            // If no order exists for the user, create a new one
            order = new Order({
                username,
                orders: [{
                    products: formattedProducts, // Use formatted products
                    shippingInfo: {
                        ...shippingInfo,
                        deliveryDate, // Set calculated delivery date
                        flexibleDeliveryDay, // Include flexible delivery day
                    },
                    paymentMethod,
                    paymentStatus,
                    totalAmount,
                    createdAt: Date.now(),
                }],
            });
            await order.save();
        }

        console.log('Order saved successfully:', order);

        // Send confirmation email to the user
        await sendOrderConfirmation(shippingInfo.email, order._id, username);
        
        // Notify admin about the new order
        await notifyAdmin(order._id, username);

        res.status(201).json({ message: 'Order placed successfully!', order });
    } catch (error) {
        console.error('Error placing order:', error);
        res.status(500).json({ message: 'Order placement failed', error });
    }
});

// Route to send order confirmation email
router.post('/send-confirmation', async (req, res) => {
    const { email, orderId, username } = req.body;

    try {
        await sendOrderConfirmation(email, orderId, username);
        res.status(200).json({ message: 'Confirmation email sent successfully!' });
    } catch (error) {
        console.error('Error sending confirmation email:', error);
        res.status(500).json({ message: 'Failed to send confirmation email', error });
    }
});

// Route to notify admin
router.post('/notify-admin', async (req, res) => {
    const { orderId, username } = req.body;

    try {
        await notifyAdmin(orderId, username);
        res.status(200).json({ message: 'Admin notified successfully!' });
    } catch (error) {
        console.error('Error notifying admin:', error);
        res.status(500).json({ message: 'Failed to notify admin', error });
    }
});


// Route to get orders for a user
router.get('/orders/:username', async (req, res) => {
    const { username } = req.params;

    try {
        const orders = await Order.findOne({ username });
        if (!orders) {
            return res.status(404).json({ message: 'No orders found for this user' });
        }
        res.status(200).json(orders);
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).json({ message: 'Failed to fetch orders', error });
    }
});

module.exports = router;
