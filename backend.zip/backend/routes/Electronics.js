

const express = require('express');
const router = express.Router();
const Electronics = require('../models/Electronics');

// Get all electronics
router.get('/', async (req, res) => {
  try {
    const electronics = await Electronics.find();
    res.json(electronics);
   
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get a single electronic product by ID
router.get('/:id', async (req, res) => {
  try {
    const electronic = await Electronics.findById(req.params.id);
    if (!electronic) return res.status(404).json({ message: 'Product not found' });
    res.json(electronic);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});





module.exports = router;

