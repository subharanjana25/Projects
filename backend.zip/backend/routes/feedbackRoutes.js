

// routes/feedbackRoutes.js
const express = require('express');
const router = express.Router();
const Feedback = require('../models/Feedback');

// POST request to submit feedback
router.post('/', async (req, res) => {
  const { name, email, message, rating } = req.body;

  try {
    // Ensure rating is between 1 and 5
    if (rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Rating must be between 1 and 5.' });
    }

    const newFeedback = new Feedback({ name, email, message, rating });
    await newFeedback.save();
    res.status(201).json({ message: 'Feedback submitted successfully!' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to submit feedback. Please try again.' });
  }
});

module.exports = router;
