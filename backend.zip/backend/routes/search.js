// backend/routes/searchRoutes.js

const express = require('express');
const router = express.Router();
const Electronics = require('../models/Electronics');
const Furniture = require('../models/Furniture');

// Search Route
router.get('/', async (req, res) => {
  try {
    const query = req.query.query;
    if (!query) return res.status(400).json({ message: 'Query parameter is required' });

    // Search in Furniture
    const furnitureResults = await Furniture.find({
      $text: { $search: query }
    });

    // Search in Electronics
    const electronicsResults = await Electronics.find({
      $text: { $search: query }
    });

    // Combine Results
    const results = {
      furniture: furnitureResults,
      electronics: electronicsResults,
    };

    res.json(results);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
