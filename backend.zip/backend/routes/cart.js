
const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();
const Cart = require('../models/Cart');


router.get('/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        console.log('UserID:', userId); // Log userId for debugging
        
        const cart = await Cart.findOne({ userId }).populate('items.productId');
        console.log('Cart:', cart); // Log cart for debugging
        
        if (!cart) {
            console.error('Cart not found');
            return res.status(404).json({ message: 'Cart not found' });
        }
        
        res.json(cart);
    } catch (error) {
        console.error('Server error:', error); // Log error details for debugging
        res.status(500).json({ message: 'Server error', error });
    }
});

// Add to Cart
router.post('/add', async (req, res) => {
    const { userId, productId, quantity, category } = req.body;

    try {
        let cart = await Cart.findOne({ userId });

        // If the cart doesn't exist, create a new one
        if (!cart) {
            cart = new Cart({ userId, items: [] });
            console.log(userId);
            console.log(`New cart created for userId: ${userId}`);
             
        }

        // Check if the product already exists in the cart
        const itemIndex = cart.items.findIndex(item => item.productId.toString() === productId && item.category === category);

        if (itemIndex > -1) {
            // If item exists, update its quantity
            cart.items[itemIndex].quantity += quantity;
        } else {
            // If item doesn't exist, add it to the cart
            cart.items.push({ productId, quantity, category });
        }

        // Save the cart to the database, whether it's new or updated
        await cart.save();
        res.json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
        console.error('Error adding to cart:', error.message);

    }
});



router.put('/update', async (req, res) => {
    const { userId, productId, quantity, category } = req.body;

    try {
        const cart = await Cart.findOne({ userId });
        if (!cart) return res.status(404).json({ message: 'Cart not found' });

        const itemIndex = cart.items.findIndex(item => item.productId.toString() === productId && item.category === category);

        if (itemIndex > -1) {
            if (quantity <= 0) {
                cart.items.splice(itemIndex, 1); // Remove item if quantity is 0 or less
            } else {
                cart.items[itemIndex].quantity = quantity; // Update quantity
            }
        } else {
            return res.status(404).json({ message: 'Item not found in cart' });
        }

        await cart.save();
        res.json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

// Remove from Cart
router.delete('/remove/:userId/:productId/:category', async (req, res) => {
    const { userId, productId, category } = req.params;
    
    console.log(productId, category);

    try {
        const cart = await Cart.findOne({ userId });
        if (!cart) return res.status(404).json({ message: 'Cart not found' });

        cart.items = cart.items.filter(item => !(item.productId.toString() === productId && item.category === category));

        await cart.save();
        res.json(cart);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.delete('/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const deletedCart = await Cart.findOneAndDelete({ userId });

        if (!deletedCart) {
            return res.status(404).json({ message: 'Cart not found for this user.' });
        }

        res.json({ message: 'Cart deleted successfully.' });
    } catch (error) {
        console.error('Error deleting cart:', error);
        res.status(500).json({ message: 'Server error' });
    }
});


module.exports = router;

