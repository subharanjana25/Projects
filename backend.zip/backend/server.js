




const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer'); // Added nodemailer for email functionality
const User = require('./models/User');
const furnitureRoutes = require('./routes/furnitureRoutes');
const cartRoutes = require('./routes/cart');
const electronicsRoutes = require('./routes/Electronics');
const authMiddleware = require('./middleware/authMiddleware');
const path = require('path');
const feedbackRoutes = require('./routes/feedbackRoutes');
const searchRoutes = require('./routes/search');
const orderRoutes = require('./routes/orderRoutes');

require('dotenv').config();

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Serve static files from the uploads directory
app.use('/uploads', express.static(path.join(__dirname, '../admin/backend/uploads')));

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/signupDB', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected to signupDB...'))
  .catch(err => console.log(err));

// Nodemailer Transporter Configuration
const transporter = nodemailer.createTransport({
  service: 'Gmail', // You can use other services like Yahoo, Outlook
  auth: {
    user: process.env.EMAIL_USER, // Your email address
    pass: process.env.EMAIL_PASS, // Your email password or app-specific password
  },
});

// Signup Route with Email Functionality
app.post('/signup', async (req, res) => {
  const { username, email, password, phoneNumber, address } = req.body;

  try {
    // Check if the user already exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: 'User already exists' });
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Save the user in the database
    user = new User({
      username,
      email,
      password: hashedPassword,
      phoneNumber,
      address
    });

    await user.save();

    // Send Welcome Email
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Welcome to Our Store!',
      text: `Hello ${username},\n\nWelcome to our store! We're excited to have you on board.\n\nBest regards,\nThe Team`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('Error sending email: ', error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    });

    res.status(201).json({ msg: 'User registered successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Login Route with JWT
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check if the user exists
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).json({ msg: 'Username does not exist, sign up first' });
    }

    // Compare the password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Password is incorrect' });
    }

    // Create and send JWT
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '5h' });

    // Send response with token, username, and userId
    res.status(200).json({ token, username: user.username, userId: user._id, msg: 'Login successful' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get Current User Details Route
app.get('/api/users/me', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});




// Update User Details Route
app.put('/api/users/me', authMiddleware, async (req, res) => {
  const { username, email, phoneNumber, address } = req.body;

  try {
    // Find the user and update their details
    const updatedUser = await User.findByIdAndUpdate(
      req.user.userId,
      { username, email, phoneNumber, address },
      { new: true } // Return the updated user
    ).select('-password'); // Exclude password from the response

    if (!updatedUser) {
      return res.status(404).json({ msg: 'User not found' });
    }

    res.json(updatedUser);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});




// Furniture Routes
app.use('/api/furnitures', furnitureRoutes);

// Electronics Routes
app.use('/api/electronics', electronicsRoutes);

// Cart Routes
app.use('/api/cart', cartRoutes);

// Feedback Routes
app.use('/api/feedback', feedbackRoutes);


// Search Routes
app.use('/api/search', searchRoutes);

// Use order routes
app.use('/api', orderRoutes);

// Server
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
