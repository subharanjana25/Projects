const mongoose = require('mongoose');

const electronicsSchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: String, default: 'Electronics' },
  price: { type: Number, required: true },
  description: { type: String },
  brand: { type: String },
  model: { type: String },
  specifications: { type: String }, // New field to hold combined specifications
  color: { type: String },
  images: [{ type: String }] // Array to store image URLs or paths
}, { timestamps: true });

electronicsSchema.index({ name: 'text', description: 'text' });


const Electronics = mongoose.model('Electronics', electronicsSchema);

module.exports = Electronics;
