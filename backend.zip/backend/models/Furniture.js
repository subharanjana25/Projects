// const mongoose = require('mongoose');

// const FurnitureSchema = new mongoose.Schema({
//   name: {
//     type: String,
//     required: true,
//   },
//   imageUrl: {
//     type: String,
//     required: true,
//   },
//   category: {
//     type: String,
//     required: true,
//   },
//   price: {
//     type: Number,
//     required: true,
//   },
//   description: {
//     type: String,
//   },
// });

// module.exports = mongoose.model('Furniture', FurnitureSchema);



const mongoose = require('mongoose');

const FurnitureSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  images: {  // Updated to support multiple image URLs
    type: [String],
    required: true,
  },
  category: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  description: {
    type: String,
  },
});



// In your furnitureModel.js
FurnitureSchema.index({ name: 'text', description: 'text' });



module.exports = mongoose.model('Furniture', FurnitureSchema);
