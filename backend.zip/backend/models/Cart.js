


const mongoose = require('mongoose');

const cartSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    items: [{
        productId: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
        },
        quantity: {
            type: Number,
            required: true,
            default: 1,
            min: [1, 'Quantity cannot be less than 1'],
        },
        category: {
            type: String,
            required: true,
            enum: ['furniture', 'electronics'],
        },
    }],
}, {
    timestamps: true,  // Adds createdAt and updatedAt
});

// Indexing userId for faster cart retrieval
cartSchema.index({ userId: 1 });

module.exports = mongoose.model('Cart', cartSchema);



