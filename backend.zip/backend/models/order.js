
// const mongoose = require('mongoose');

// const orderSchema = new mongoose.Schema({
//     username: { type: String, required: true, unique: true }, // Ensure username is unique
//     orders: [{ // Array to store multiple orders for the user
//         products: [{
//             productId: { type: String, required: true },
//             name: { type: String, required: true },
//             price: { type: Number, required: true },
//             quantity: { type: Number, required: true },
//         }],
//         shippingInfo: {
//             name: { type: String, required: true },
//             address: { type: String, required: true },
//             phone: { type: String, required: true },
//             email: { type: String, required: true },
//             pincode: { type: String, required: true },
//             landmark: { type: String, required: true },
//             deliveryDate: { type: Date, required: true }, // Delivery date will be set on order placement
//                    },
//         paymentMethod: { type: String, required: true },
//         paymentStatus: { type: String, required: true }, // e.g., 'Pending', 'Completed'
//         totalAmount: { type: Number, required: true }, // Total amount of the order
//         deliveryStatus: { type: String, default: 'Processing' },// New delivery status field
//         createdAt: { type: Date, default: Date.now }, // Date when order is placed
//     }],
// });

// const Order = mongoose.model('Order', orderSchema);

// module.exports = Order;





const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true }, // Ensure username is unique
    orders: [{ // Array to store multiple orders for the user
        products: [{
            productId: { type: mongoose.Schema.Types.ObjectId, required: true }, // Change to ObjectId
            name: { type: String, required: true },
            price: { type: Number, required: true },
            quantity: { type: Number, required: true },
        }],
        shippingInfo: {
            name: { type: String, required: true },
            address: { type: String, required: true },
            phone: { type: String, required: true },
            email: { type: String, required: true },
            pincode: { type: String, required: true },
            landmark: { type: String, required: true },
            deliveryDate: { type: Date, required: true }, // Delivery date will be set on order placement
        },
        paymentMethod: { type: String, required: true },
        paymentStatus: { type: String, required: true }, // e.g., 'Pending', 'Completed'
        totalAmount: { type: Number, required: true }, // Total amount of the order
        deliveryStatus: { type: String, default: 'Processing' }, // New delivery status field
        createdAt: { type: Date, default: Date.now }, // Date when order is placed
    }],
});

const Order = mongoose.model('Order', orderSchema);

module.exports = Order;
